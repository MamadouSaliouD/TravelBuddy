<?php

   $connection = mysqli_connect('localhost','root','','voyage_db');

   if(isset($_POST['send'])){
      $name = $_POST['name'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $location = $_POST['location'];
      $guests = $_POST['guests'];
      $arrivals = $_POST['arrivals'];
      $departures = $_POST['departures'];

      $request = " insert into reservation(name, email, phone, address, location, guests, arrivals, departures) values('$name','$email','$phone','$address','$location','$guests','$arrivals','$departures') ";
      mysqli_query($connection, $request);

      header('location:book.php'); 
      echo 'Congrats, you did it!!';

   }else{
      echo 'something went wrong please try again!';
   }

?>