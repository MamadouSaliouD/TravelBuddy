<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>package</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">travelBuddy</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/package.jpg) no-repeat">
   <h1>packages</h1>
</div>

<!-- packages section starts  -->

<section class="packages">

   <h1 class="heading-title">Our top destinations</h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/warsaw.jpeg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Warsaw</h3>
            <p>Warsaw has undergone some rapid changes in the last 20 years since the fall of communism. It has developed into a city for new business, turned into a tourist hub and really proved why this is the true capital city, ahead of previous capitals Gniezno and Kraków. However, Warsaw still sits in the shadow of the more popular tourist destinations of Wrocław, Gdańsk and Kraków, so it’s time to prove that those who neglect Warsaw are missing out on some real gems. </p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/krakow.webp" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Krakow</h3>
            <p>Wonderful Main Market Square<br/>This is the first amongst Poland destinations you should start your visit in Krakow with. Main Market Square is the largest medieval market in Europe and a famous hub of social life for youth and young tourists traveling from around the world. a busy urban space today, it dates back to the 13th century.
            Location: 0-062 Kraków, Poland.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/gdansk.webp" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Gdansk</h3>
            <p>Poland’s Baltic seaside city of Gdańsk has sat in the background for years as one of the most underrated cities in Europe. For a long time, this sleeping giant went unnoticed, until recently when the city suddenly became hugely popular with tourists. Gdańsk is a city is steeped in history and brimming with activities all year round. Did you know – Culture Trip now does bookable, small-group trips? Pick from authentic, immersive Epic Trips, compact and action-packed Mini Trips and sparkling, expansive Sailing Trips.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/wroclaw.webp" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Wroclaw</h3>
            <p>This stunning island is one of the oldest areas in Wroclaw. Bound by the River Oder, there are many prominent monuments on this island such as the Cathedral of Saint John the Baptist (restored after World War II), the Holy Cross and Saint Bartholomew’s Collegiate. The place has some fantastic architecture. Be charmed by the aesthetic and historic buildings here.
            Location: Ostrow Tumski, Wroclaw, Poland
            Timings:: 8:00 AM – 7:00 PM</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/wieliczka.WEBP" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Wieliczka</h3>
            <p>Wieliczka Salt Mine<br>Another one of the UNESCO sites, Wieliczka Salt Mine has been open since the time of middle ages and takes about 2 hours to tour the entire place. This mine goes as deep as 140 feet under the ground level and has plenty of stairs which will help burn some calories. The experience of traveling through this stunning site also feels like moving towards the centre of the Earth as per some travelers.
            Location: Jana Mikołaja Daniłowicza 10, 32-020 Wieliczka</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/zakopane.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour in Zakopane</h3>
            <p>Do you like the mountains? Whether it is for skiing in winter or for long hikes in summer ... Your favorite destinations are the Alps or the Pyrenees?
            We are sending you to the Tatry and more specifically to Zakopane in Poland. Little known but which has nothing to envy to its cousins like Courchevel or Val Thorens.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/zakopane2.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour</h3>
            <p>Lying on the lower slopes of the Tatras, Poland’s most famous mountain resort is a great place to visit if you love the outdoors. However, due to Zakopane’s fantastic hiking and skiing, it can get a bit too crowded in the high months of both summer and winter.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/photo.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour</h3>
            <p>Located on the Vistula, this lovely city is an absolute delight to wander around – its peaceful streets seem a world away from more popular tourist destinations in Poland. A walled city, Torun’s Gothic old town has some fantastic architecture for visitors to view.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/couple.jpeg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour</h3>
            <p>Located in the Old Town on the beautiful Castle Square, it housed Polish royalty between the 16th and the 18th century. It was rebuilt in the 1980’s after being destroyed in the Second World War. Don’t miss out on the the series of portraits of Polish kings and 23 18th-century paintings of Warsaw.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/booknow.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour</h3>
            <p>Known as the winter capital of Poland, Zakopane is a winter wonderland that is also filled with things to do year-round. We were blessed with the chance to visit Zakopane in both seasons and enjoy everything it has to offer.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/sopot.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour Sopot, Gdansk</h3>
            <p>A popular seaside resort, Sopot attracts the rich and famous with its elegant villas, posh restaurants and pounding nightlife. Formerly a fishing village, its packed and overdeveloped seafront now obscures the relics of the past, but you can still find traces of what it used to be like hidden around the city.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-12.jpg" alt="">
         </div>
         <div class="content">
            <h3>adventure & tour</h3>
            <p>Unlike any other city in Poland, Gdansk’s tumultuous history has resulted in a unique identity and look. Due to its large port, wealthy merchants coming here to trade left their mark, while its strategic location meant it was once fought over by Teutonic Prussia and Poland.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

   </div>

   <div class="load-more"><span class="btn">load more</span></div>

</section>

<!-- packages section ends -->




<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +48 674 876 634 </a>
         <a href="#"> <i class="fas fa-phone"></i> +48 745 876 654 </a>
         <a href="#"> <i class="fas fa-envelope"></i> TravelBuddy@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Warsaw, Poland - 312-045 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>TravelBuddy Group</span> | all rights reserved! </div>

</section>

<!-- footer section ends -->



<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>